package com.ohms.userservice.entity;

public enum Role {
    RECEPTIONIST,
    MANAGER,
    OWNER,
    DEVELOPER,
}
